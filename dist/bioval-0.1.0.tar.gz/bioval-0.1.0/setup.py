# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['bioval', 'bioval.metrics', 'bioval.tests', 'bioval.tutorials', 'bioval.utils']

package_data = \
{'': ['*'], 'bioval.tutorials': ['data/.placeholder', 'images/*']}

install_requires = \
['Pillow',
 'numpy',
 'nvidia-ml-py',
 'piq',
 'pot',
 'scikit-learn',
 'torch',
 'torchvision']

setup_kwargs = {
    'name': 'bioval',
    'version': '0.1.0',
    'description': 'The bioval package provides a comprehensive and accessible platform for evaluating the performance of generative models in the field of deep learning. By offering a simple and intuitive interface, this library simplifies the process of analyzing results from natural image domains as well as high content screening in the context of drug discovery. Built specifically for usage with PyTorch and PyTorch Lightning, bioval is easily integrated into existing workflows and offers additional metrics adapted for the biological setting. This makes it an indispensable tool for researchers and practitioners in the field of machine learning and deep learning, who are focused on the development of generative models. With the support of numpy, torch, torchvision, Pillow, and nvidia-ml-py, bioval provides a robust and versatile solution for evaluating the results of generative models. Whether you are a senior researcher or a practitioner, bioval will provide you with a sophisticated and efficient means of evaluating your models, while also saving you time and effort in the process.',
    'long_description': '# Bioval\nBioval is a Python package that provides a collection of evaluation metrics for comparing the similarity of two tensors. The package supports tensors of shape (N, I, H, W, C) or (N, H, W, C) or (N, I, F) or (N, F), where N is the number of classes, I is the number of instances, H is the height, W is the width, C is the number of channels, and F is the number of features.\n\n## Installation\nBioval can be installed from PyPI using the following command:\n\n```bash\npoetry build\npip3 install dist/bioval-{version_number}.tar.gz\n```\n\n## Usage\nTo use Bioval, create an instance of one of the evaluation classes, and call the __call__ method, passing in two tensors and a range of k values:\n\n```python\nfrom bioval.metrics import ConditionalEvaluation\n\ntopk = ConditionalEvaluation()\n\n# Test on 2D tensors\narr1 = torch.randn(100, 10)\narr2 = torch.randn(100, 10)\nprint("2D tensors")\nstart_time = time.time()\nprint(topk(arr1, arr2, k_range=[1, 5, 10, 20, 50, 100]))\nprint("Time elapsed: {:.2f}s".format(time.time() - start_time))\n\n# Repeat test on 3D tensors\narr1 = torch.randn(100, 10, 10)\narr2 = torch.randn(100, 10, 10)\nprint("3D tensors")\nstart_time = time.time()\nprint(topk(arr1, arr2, k_range=[1, 5, 10, 20, 50, 100]))\nprint("Time elapsed: {:.2f}s".format(time.time() - start_time))\n```\n\n## Available Metrics\nThe following evaluation metrics are available in Bioval:\n\n### IntraClass Conditional Evaluation\nThis metric measures the top-k similarity between two tensors, both within and across classes. The metric returns the following scores: intra_top1, intra_top5, inter_corr, inter_p, mean_ranks, and exact_matching.\n\n### InterClass Conditional Evaluation\nOther evaluation metricswill soon be also available in Bioval. Please refer to the documentation for details on how to use these metrics.\n\n### Distance from Control\nOther evaluation metricswill soon be also available in Bioval. Please refer to the documentation for details on how to use these metrics.\n\n### Usage \n\n#### Aggregated \n\n```python\nfrom bioval.metrics import ConditionalEvaluation\n\n# Create an instance of the ConditionalEvaluation class\ntopk = ConditionalEvaluation()\n\n# Compute top-k similarity scores between two tensors\narr1 = torch.randn(100, 10)\narr2 = torch.randn(100, 10)\nscores = topk(arr1, arr2, k_range=[1, 5, 10, 20, 50, 100])\n```\n\n#### Distributed \n```python\n\nfrom bioval.metrics import ConditionalEvaluation\n\ntopk = ConditionalEvaluation(distributed_method=\'fid\') # or \'kid\' or \'mmd\'\narr1 = torch.randn(30, 20, 10, 10, 3) * 256\narr2 = torch.randn(30, 20, 10, 10, 3) * 256\nprint(topk(arr1, arr2, k_range=[1, 5, 10],aggregated=False)) # returns a dict of scores\n```\n\n## Documentation\nPlease refer to the docstrings in the code for detailed documentation on each metric.\n\n## Contributing\nContributions are welcome! Please refer to the [Contribute]() file for details on how to contribute to Bioval.\n\n## License\nBioval is licensed under the MIT License. Please refer to the [License]() file for details.\n',
    'author': 'Ihab Bendidi',
    'author_email': 'bendidiihab@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
