# Bioval

## Installation 

### Install from PyPI

```bash
poetry build
pip3 install dist/bioval-{version_number}.tar.gz
```